create function add_club_card_func() returns trigger
    language plpgsql
as
$$
BEGIN
	if new.id_role = 1 then
		insert into club_cards values (default, new.id_user, default);
	end if;
    RETURN NEW;
	end;
	$$;

alter function add_club_card_func() owner to postgres;

